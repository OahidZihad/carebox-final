import React from 'react'
import './Landing.css'
const Footer = () => {
    return (
        <div>
            <div className="footer">

            </div>
        </div>
    )
}

export default Footer
