import React from "react";
import { Container, Row, Col, Navbar } from "react-bootstrap";
import logo from "../media/logo.png";
import Rating from "@mui/material/Rating";
import {Button} from 'react-bootstrap';
import doc_image from "../media/img_avatar.png";
import { useHistory } from "react-router";
import "./Landing.css";
import Footer from "./Footer";

const EachDoctor = () => {
  const history = useHistory();
  const HandleClickSession = (e) => {
    e.preventDefault();
    history.push('/DoctorForm');
  }
  return (
    <div>
      <div className="headerBox2">
        <Navbar>
          <Container>
            <Navbar.Brand href="/">
              <img src={logo} alt="logo" fluid style={{ height: "80px" }} />
            </Navbar.Brand>
            <Navbar.Toggle />
            <Navbar.Collapse className="justify-content-end">
              <Navbar.Text>
                <input
                  type="text"
                  placeholder="এখানে ডাক্তার সার্চ করুন......"
                />
              </Navbar.Text>
            </Navbar.Collapse>
          </Container>
        </Navbar>
      </div>
      <br />
      <br />
      <br />
      <Container style={{textAlign: "left"}}>
        <Row>
          <Col md={6} xs={6}>
            <h2 style={{ fontSize: "25px" }}>ডাঃ সালমান</h2>
            <p style={{ fontSize: "15px", marginBottom: "0rem" }}>মেডিসিন বিশেষজ্ঞ</p>
            <Rating
              name="size-small"
              defaultValue={4.5}
              precision={0.5}
              readOnly
            />
            <p style={{ fontSize: "10px" }}>সময়ঃ বিকেল ৫ টা - রাত ৮ টা</p>
            <button className="charge_fifty">চার্জঃ ৫০ টাকা</button>
            <h4 className="session_25">(প্রতি সেশনঃ ২৫ মিনিট)</h4>
            <br />
            <div className="doctor_desc">
              <h5>ডাক্তারের বিবরণঃ</h5>
              <p>
                কেউই প্রতিদিন মাত্র ১ টাকার বিনিময়ে কোনও রকম বিজ্ঞাপনের উপদ্রব
                ছাড়াই এক হাজারেরও বেশি ব্লক বাস্টার সিনেমা দেখা যাবে। কেউই
                প্রতিদিন মাত্র ১ টাকার বিনিময়ে কোনও রকম বিজ্ঞাপনের উপদ্রব ছাড়াই
                এক হাজারেরও বেশি ব্লক বাস্টার সিনেমা দেখা যাবে।
              </p>
            </div>
            <Button variant="warning" onClick={HandleClickSession} style={{fontSize: "20px", fontWeight: "bold", left: "20%", marginLeft: "30%"}}>সেশন বুক করুন</Button>
          </Col>
          <Col md={1} xs={1}></Col>
          <Col md={5} xs={5}>
            <div className="each_doctor_image">
                {/* <img src={doc_image} alt="doctor name" /> */}
            </div>
          </Col>
        </Row>
      </Container>
      <br />
      <Footer />
    </div>
  );
};

export default EachDoctor;
