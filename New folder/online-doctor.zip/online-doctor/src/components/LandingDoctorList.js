import React from 'react'
import {Container, Row, Col} from 'react-bootstrap'
import DoctorCard from './DoctorCard'

const LandingDoctorList = () => {
    return (
        <div>
            <Container>
                <div className="doctor_title_flex">
                    <div className="doctor_title_flex_left">মেডিসিন বিভাগ</div>
                    <div className="doctor_title_flex_right">সকল ডাক্তার দেখুন</div>
                </div>
                <br />
                <Container>
                    <Row>
                        <Col><DoctorCard /></Col>
                        <Col><DoctorCard /></Col>
                        <Col><DoctorCard /></Col>
                    </Row>
                </Container>
            </Container>
            <br />
            <br />
            <br />
            <Container>
                <div className="doctor_title_flex">
                    <div className="doctor_title_flex_left">সাইকোলজি বিভাগ</div>
                    <div className="doctor_title_flex_right">সকল ডাক্তার দেখুন</div>
                </div>
                <br />
                <Container>
                    <Row>
                        <Col><DoctorCard /></Col>
                        <Col><DoctorCard /></Col>
                        <Col><DoctorCard /></Col>
                    </Row>
                </Container>
            </Container>
            <br />
            <br />
            <br />
            <Container>
                <div className="doctor_title_flex">
                    <div className="doctor_title_flex_left">মেডিসিন বিভাগ</div>
                    <div className="doctor_title_flex_right">সকল ডাক্তার দেখুন</div>
                </div>
                <br />
                <Container>
                    <Row>
                        <Col><DoctorCard /></Col>
                        <Col><DoctorCard /></Col>
                        <Col><DoctorCard /></Col>
                    </Row>
                </Container>
            </Container>
            <br />
            <br />
            <br />
            <Container>
                <div className="doctor_title_flex">
                    <div className="doctor_title_flex_left">গাঈণী বিভাগ</div>
                    <div className="doctor_title_flex_right">সকল ডাক্তার দেখুন</div>
                </div>
                <br />
                <Container>
                    <Row>
                        <Col><DoctorCard /></Col>
                        <Col><DoctorCard /></Col>
                        <Col><DoctorCard /></Col>
                    </Row>
                </Container>
            </Container>
            <br />
            <br />
            <br />
        </div>
    )
}

export default LandingDoctorList
