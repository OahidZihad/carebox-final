import React from "react";
import { Navbar, Container, Row, Col, Form, Button } from "react-bootstrap";
import { useHistory } from "react-router";
import Rating from "@mui/material/Rating";
import Footer from "./Footer";
import logo from "../media/logo.png";

const DoctorForm = () => {
  const history = useHistory();
  const HandleClickSession = (e) => {
    e.preventDefault();
    history.push("/countdown");
  };
  return (
    <div>
      <div className="headerBox2">
        <Navbar>
          <Container>
            <Navbar.Brand href="/">
              <img src={logo} alt="logo" fluid style={{ height: "80px" }} />
            </Navbar.Brand>
            <Navbar.Toggle />
            <Navbar.Collapse className="justify-content-end">
              <Navbar.Text>
                <p style={{ fontWeight: "900" }}>স্বাগতম, সিফাত</p>
              </Navbar.Text>
            </Navbar.Collapse>
          </Container>
        </Navbar>
      </div>
      <br />
      <br />
      <br />
      <div>
        <Container>
          <Row>
            <Col className="online_appinment_form" xs={6} md={4}>
              <Form>
                <h2 style={{ fontSize: "20px", fontWeight: "700" }}>
                  ফরম পূরণ করুনঃ
                </h2>
                <br />
                <h4>রোগীর নাম:</h4>
                <Form.Control
                  type="text"
                  placeholder=""
                  style={{
                    backgroundImage: "linear-gradient(#090610, #701657)",
                    color: "#fff",
                    opacity: "62%",
                  }}
                />
                <br />
                <h4>মোবাইল নাম্বার:</h4>
                <Form.Control
                  type="text"
                  placeholder=""
                  style={{
                    backgroundImage: "linear-gradient(#090610, #701657)",
                    color: "#fff",
                    opacity: "62%",
                  }}
                />
                <br />
                <h4>রোগীর বয়স:</h4>
                <Form.Control
                  type="text"
                  placeholder=""
                  style={{
                    backgroundImage: "linear-gradient(#090610, #701657)",
                    color: "#fff",
                    opacity: "62%",
                  }}
                />
                <br />
                <h4>আপনি কি পুরুষ/মহিলা/অন্যান্য: </h4>
                <div className="form-check form-check-inline">
                  <input
                    name="group1"
                    type="radio"
                    className="form-check-input"
                    style={{
                      backgroundImage: "linear-gradient(#090610, #701657)",
                      opacity: "62%",
                    }}
                  />
                  <label title className="form-check-label">
                    পুরুষ
                  </label>
                </div>
                <div className="form-check form-check-inline">
                  <input
                    name="group1"
                    type="radio"
                    className="form-check-input"
                    style={{
                      backgroundImage: "linear-gradient(#090610, #701657)",
                      color: "#fff",
                      opacity: "62%",
                    }}
                  />
                  <label title className="form-check-label">
                    মহিলা
                  </label>
                </div>
                <div className="form-check form-check-inline">
                  <input
                    name="group1"
                    type="radio"
                    className="form-check-input"
                    style={{
                      backgroundImage: "linear-gradient(#090610, #701657)",
                      color: "#fff",
                      opacity: "62%",
                    }}
                  />
                  <label title className="form-check-label">
                    অন্যান্য
                  </label>
                </div>
                <br />
                <br />
                <h4>সময় নির্ধারণ করুন:</h4>
                <Form.Control
                  type="text"
                  placeholder=""
                  style={{
                    backgroundImage: "linear-gradient(#090610, #701657)",
                    color: "#fff",
                    opacity: "62%",
                  }}
                />
                <br />
                <h4>সমস্যার বিবরণ:</h4>
                <Form.Control
                  as="textarea"
                  rows={3}
                  style={{
                    backgroundImage: "linear-gradient(#090610, #701657)",
                    color: "#fff",
                    opacity: "62%",
                  }}
                />
                <br />
                <Button
                  variant="warning"
                  onClick={HandleClickSession}
                  style={{
                    fontSize: "20px",
                    fontWeight: "bold",
                    left: "20%",
                    marginLeft: "30%",
                  }}
                >
                  সেশন বুক করুন
                </Button>
              </Form>
            </Col>
            <Col xs={2} md={4}></Col>
            <Col style={{textAlign: "left"}} xs={4} md={4}>
              <br />
              <div className="each_doctor_image">
                {/* <img src={doc_image} alt="doctor name" /> */}
              </div><br />
              <h2 style={{ fontSize: "25px" }}>ডাঃ সালমান</h2>
              <p style={{ fontSize: "15px", marginBottom: "0rem" }}>
                মেডিসিন বিশেষজ্ঞ
              </p>
              <Rating
                name="size-small"
                defaultValue={4.5}
                precision={0.5}
                readOnly
              />
              <p style={{ fontSize: "15px" }}>সময়ঃ <span style={{fontSize: "12px"}}>বিকেল ৫ টা - রাত ৮ টা</span></p>
              <button className="charge_fifty">চার্জঃ ৫০ টাকা</button>
              <h4 className="session_25">(প্রতি সেশনঃ ২৫ মিনিট)</h4>
              <br />
            </Col>
          </Row>
        </Container>
      </div>
      <br />
      <Footer />
    </div>
  );
};

export default DoctorForm;
