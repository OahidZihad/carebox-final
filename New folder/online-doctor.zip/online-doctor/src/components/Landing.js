import React from 'react';
import HeaderBox from './HeaderBox';
import LandingDoctorTitle from './LandingDoctorTitle';
import LandingDoctorList from './LandingDoctorList';
import Footer from './Footer';

const Landing = () => {
    return (
        <div>
            <HeaderBox />
            <br />
            <LandingDoctorTitle />
            <br />
            <LandingDoctorList />
            <br />
            <Footer />
        </div>
    )
}

export default Landing
