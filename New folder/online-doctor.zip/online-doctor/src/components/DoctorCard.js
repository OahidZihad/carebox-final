import React from "react";
import doc_image from "../media/img_avatar.png";
import {Button} from 'react-bootstrap';
import {useHistory} from 'react-router-dom'
import Rating from '@mui/material/Rating';

const DoctorCard = () => {
  const history = useHistory();
  const handleButtonPush = () => {
    history.push('/online-doctor')
  }
  return (
    <div className="doctor_card_container">
      <div className="doctor_content">
        <div className="doctor_flex">
          <div className="doctor_flex_image">
            <img src={doc_image} alt="doctor name" />
          </div>
          <div className="doctor_flex_details">
            <h2 style={{fontSize: "25px"}}>ডাঃ সালমান</h2>
            <p style={{fontSize: "15px"}}>মেডিসিন বিশেষজ্ঞ</p>
            <Rating name="size-small" defaultValue={4.5} precision={0.5} readOnly />
            <p  style={{fontSize: "10px"}}>সময়ঃ বিকেল ৫ টা - রাত ৮ টা</p>
            <Button variant="warning" style={{fontSize: "10px", fontWeight: "bold"}} onClick={handleButtonPush}>সেশন বুক করুন</Button>
          </div>
        </div>
        <div className="doctor_desc">
          <h5>বিবরণঃ</h5>
          <p>
            কেউই প্রতিদিন মাত্র ১ টাকার বিনিময়ে কোনও রকম বিজ্ঞাপনের উপদ্রব
            ছাড়াই এক হাজারেরও বেশি ব্লক বাস্টার সিনেমা দেখা যাবে। কেউই প্রতিদিন
            মাত্র ১ টাকার বিনিময়ে কোনও রকম বিজ্ঞাপনের উপদ্রব ছাড়াই এক হাজারেরও
            বেশি ব্লক বাস্টার সিনেমা দেখা যাবে।
          </p>
        </div>
      </div>
    </div>
  );
};

export default DoctorCard;
