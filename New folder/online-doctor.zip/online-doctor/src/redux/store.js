import { createStore, applyMiddleware, combineReducers } from "redux";
import thunk from 'redux-thunk'
import { composeWithDevTools } from "redux-devtools-extension";
//import { OnlineAppoinmentDoctorReducer, OnlineAppoinmentCategoryReducer } from './reducers/OnlineAppoinmentDoctorReducers';

const reducer = combineReducers({
//   online appoinment
//   OnlineAppoinmentDoctor: OnlineAppoinmentDoctorReducer,
//   OnlineAppoinmentCategory: OnlineAppoinmentCategoryReducer
});
  
const initialState = {
  userLogin: { userInfo: userInfoFromStorage },
}

const middleware = [thunk];

const store = createStore(
  reducer,
  initialState,
  composeWithDevTools(applyMiddleware(...middleware))
)

export default store;
