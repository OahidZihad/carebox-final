import { ONLINE_DOCTOR_LIST_REQUEST, ONLINE_DOCTOR_LIST_SUCCESS, ONLINE_DOCTOR_LIST_FAILURE } from '../Type'
import { ONLINE_DOCTOR_CATEGORY_REQUEST, ONLINE_DOCTOR_CATEGORY_SUCCESS, ONLINE_DOCTOR_CATEGORY_FAILURE } from '../Type'
import { ONLINE_DOCTOR_PROFILE_REQUEST, ONLINE_DOCTOR_PROFILE_SUCCESS, ONLINE_DOCTOR_PROFILE_FAILURE } from '../Type'

export const OnlineAppoinmentDoctorReducer = (state = { onlineAppoinment: [] } , action) => {
    switch(action.type){
        case ONLINE_DOCTOR_LIST_REQUEST:
            return {
                loading: true,
                onlineAppoinment: []
            }
        case ONLINE_DOCTOR_LIST_SUCCESS:
            return{
                loading: false,
                onlineAppoinment: action.payload
            }
        case ONLINE_DOCTOR_LIST_FAILURE:
            return {
                loading: false,
                error: "something problem"
            }
        default:
            return state;
    }
}

export const OnlineAppoinmentCategoryReducer = (state = { onlineAppoinmentCategory: [] } , action) => {
    switch(action.type){
        case ONLINE_DOCTOR_CATEGORY_REQUEST:
            return {
                loading: true,
                onlineAppoinmentCategory: []
            }
        case ONLINE_DOCTOR_CATEGORY_SUCCESS:
            return{
                loading: false,
                onlineAppoinmentCategory: action.payload
            }
        case ONLINE_DOCTOR_CATEGORY_FAILURE:
            return {
                loading: false,
                error: "something problem"
            }
        default:
            return state;
    }
}

export const OnlineDoctorProfileReducer = (state = { onlineDoctorProfile: [] } , action) => {
    switch(action.type){
        case ONLINE_DOCTOR_PROFILE_REQUEST:
            return {
                loading: true,
                onlineDoctorProfile: []
            }
        case ONLINE_DOCTOR_PROFILE_SUCCESS:
            return{
                loading: false,
                onlineDoctorProfile: action.payload
            }
        case ONLINE_DOCTOR_PROFILE_FAILURE:
            return {
                loading: false,
                error: "something problem"
            }
        default:
            return state;
    }
}