import './App.css';
import Landing from './components/Landing';
import EachDoctor from './components/EachDoctor';
import DoctorForm from './components/DoctorForm';
import {
  BrowserRouter as Router,
  Switch,
  Route
} from "react-router-dom";
import CountdownTimer from './components/CountdownTimer';

function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route path="/online-doctor" component={EachDoctor}></Route>
          <Route path="/DoctorForm" component={DoctorForm}></Route>
          <Route path="/countdown" component={CountdownTimer}></Route>
          <Route path="/" component={Landing} exact></Route>
        </Switch>
      </Router>
    </div>
  )
}

export default App;